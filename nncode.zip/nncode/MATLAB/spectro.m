function [TF, freq, time] = spectro(x,secs,fftint,maxfreq)
%SPECTRO Spectrogram of audio signal.
%   [TF, freq, time] = spectro(x,secs,fftint,maxfreq returns the STFT, 
%   frequency and time for the specified signal (x), its duration in 
%   seconds (secs), the duration of the STFT interval in seconds (fftint),
%   and the maximum frequency of the FFT (maxfreq).
%
%   The signal x must be a .wav file, and the duration of x specified
%   must not be less than its actual duration. Additionally, the duration
%   of the short-time Fourier transform interval (fftint) must not be
%   greater than the total duration. Finally, the maxfreq must be half
%   of the sampling frequency, usually 22050 Hz.
%   
%   SPECTRO will return the spectrogram and surface of a specified signal.
%   It does this by partitioning the file according to fftint, normalizing
%   the data to fit the requirements for the FFT, and then taking the 
%   short-time Fourier transform (STFT). A spectrogram is a three
%   dimensional output wherein the abscissa is time or sample number (the
%   two are dependent), the ordinate is frequency in Hz, and the darkness
%   of the color of a given point represents its amplitude in decibels. So,
%   a white point would not be as loud as a gray or black point. Also
%   output is the surface of the spectrogram.
%
%   A spectrogram is a nice way of displaying the three components of
%   audio: time, frequency, and intensity. With the Fourier transform, one
%   limits oneself to just frequency and amplitude; and of couse with just
%   the signal, we only have time and amplitude. However, it is not quite
%   as easy to identify spectral components with a spectrogram, simply
%   because there is a lot of information to keep in mind. A spectrogram is
%   most useful in the visualization of formants in speech. With respect to
%   music, you can identify drums and other inharmonic instruments by their
%   brightness and "noisy" results in the spectrogram. Harmonic instruments
%   like the voice or woodwinds will appear in the higher end of the
%   frequency domain and will have a logarithmic pattern, and straight
%   horizontal lines.
%
%   Copyright 2011 by Regina Collecchia

    [m d]=wavfinfo(x);
    [x,fs,nbits]=wavread(x);
    if isempty(m)==1
        error('The specified file is not .wav file.')
        x=0
    end
    if fs.*secs<length(x)
        error('The specified duration (secs) is too short.')
        secs=0
    end
    if fftint>maxfreq
        error('The specified duration for the intervals of the FFT (fftint) is too large.')
        fftint=0
    end
    if maxfreq>fs/2
        error('The specified maximum frequency (maxfreq) is beyond the Nyquist sampling rate.')
        maxfreq=0
    end
   
    partitionsize=fftint*fs;
    window=hanning(partitionsize);
    partitions=[1:partitionsize:length(x)-partitionsize];
    Z=zeros(partitionsize,length(partitions));
    for i=1:length(partitions)
        Z(1:partitionsize, i)=x(partitions(i):partitions(i)+partitionsize-1).*window;
    end
    
    % take the Short Term Fourier Transform (STFT)
    STFT = fft(Z);
    
    % take absolute value of each partition
    if rem(partitionsize,2)==1
        k=(partitionsize+1)/2;
    else
        k=partitionsize/2;
    end
    
    f=[0:k-1]*fs/partitionsize;
    t=partitions/fs;
    
    if nargout>0, TF=STFT; end
    if nargout>1, freq=f; end
    if nargout>2, time=t; end
    
    maxSTFT=abs(STFT(2:partitionsize*maxfreq/fs,:)); % size of the STFT
    maxSTFT=maxSTFT/max(max(maxSTFT)); % normalized so the max amplitude will be 0 db
   
    figure
    % output the spectrogram with color specifying intensity in dB's
    pcolor(t, f(2:partitionsize*maxfreq/fs), 20*log10(maxSTFT));
    axis xy;
    colormap(flipud(bone));
    shading interp;
    title('2D Spectrogram of the signal')
    xlabel('Time (seconds)')
    ylabel('Frequency (Hz)')
    
    figure
    surf(t, f(2:partitionsize*maxfreq/fs),20*log10(maxSTFT));
    axis xy;
    view(20,84);
    colormap(flipud(bone));
    shading interp;
    title('3D Spectrogram of the signal')
    xlabel('Time (seconds)')
    ylabel('Frequency (Hz)')
    
end
    
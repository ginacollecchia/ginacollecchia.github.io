%% Take the fast Fourier transform of a WAV file
%% and plot its power.
%%
%% Copyright Regina Collecchia 2011-2012.

[x,fs] = wavread('Trumpet-01-mf-C5.wav');
N = length(x); %% number of points in an audio file is just its length
T = length(x)/fs; %% define time of interval in seconds
t = [0:N-1]/N; %% define time instants
t = t*T; %% define time in seconds
p = abs(fft(x))/(N/2); %% absolute value of the fft, we only need the first half of it
p = p(1:N/2).^2; %% take the power of first half of the freq's
freq = [0:N/2-1]/T; %% find the corresponding frequency in Hz
figure
plot(freq, p, 'k')
axis([0 5000 0 0.012]) %% zoom in

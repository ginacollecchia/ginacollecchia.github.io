#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

/* Definitions */

#define strchr index
#define length 32768		/* maximum points in FFT - must be power of 2 */
#define PI	M_PI			/* Pi as defined in math.h, to machine precision */
#define TWOPI	(2.0*PI)	/* 2 times Pi, used quite often */

void four1();
void realft();

double wsum;
char *pname;
FILE *ifile;
int m, n;
int cflag;
int decimation = 1;
int smooth = 1;			/* Adjust this variable for scaling your FFT output */
static float *c;
double norm;

main(argc, argv)
int argc;
char *argv[];
{
	int i;
	char *prog_name();
	double atof();
	pname = prog_name(argv[0]);
	if (--argc < 1) 
	{
		exit(1);
   	}
	else if ((ifile = fopen(argv[argc], "rt")) == NULL) 
	{
		fprintf(stderr, "%s: can't open %s\n", pname, argv[argc]);
		exit(2);
   	}

	if ((c = (float *)calloc(length, sizeof(float))) == NULL) 
	{
		fprintf(stderr, "%s: insufficient memory\n", pname);
		exit(2);	
	}
	
	read_input();
	fft();
	fft_print();
	
	exit(0);
}

read_input()
{
	for (n = 0; n < length && fscanf(ifile, "%f", &c[n]) == 1; n++);
}

/* calculate forward FFT */
fft()		
{
	int i;
	for (m = length; m >= n; m >>= 1);
	m <<= 1;								/* m is now the smallest power of 2 >= n */
	wsum = m;
	norm = sqrt(2.0/(wsum*n));
  	realft(c-1, m/2, 1);					/* perform the FFT - see Numerical Recipes 12.2 */
}

/* 
	print the FFT results to console as real numbers
*/
fft_print()	
{
   	int i;
   	c[m] = c[1];							/* Unpack FFT data array */
   	c[1] = c[m+1] = 0.;
   	for (i = 0; i <= m; i += 2*decimation) 
	{
		int j;
		double pow;

		for (j = 0, pow = 0.0; j < 2*smooth; j += 2)
	   	{
			pow += (c[i+j]*c[i+j] + c[i+j+1]*c[i+j+1])*norm*norm;
	   	}
		pow /= smooth/decimation;
		printf("%g", sqrt(pow));			/* Print FFT results */ 
		printf("\n");
	}
}

char *prog_name(s)
char *s;
{
	char *p = s + strlen(s);
	
	while (p >= s && *p != '/')
	{
		p--;
	}
	
   	return (p+1);
}

void realft(data,n,isign)
float data[];
int n,isign;
{
    int i, i1, i2, i3, i4, n2p3;
    float c1 = 0.5, c2, h1r, h1i, h2r, h2i;
    double wr, wi, wpr, wpi, wtemp, theta;
    void four1();

    theta = PI/(double) n;
	if (isign == 1) 
	{
		c2 = -0.5;
		four1(data, n, 1);
   	} 
	else 
	{
		c2 = 0.5;
		theta = -theta;
   	}
   	wtemp = sin(0.5*theta);
   	wpr = -2.0*wtemp*wtemp;
   	wpi = sin(theta);
   	wr = 1.0+wpr;
   	wi = wpi;
   	n2p3 = 2*n+3;
   	for (i = 2; i <= n/2; i++) 
	{
		i4 = 1 + (i3 = n2p3 - (i2 = 1 + ( i1 = i + i - 1)));
		h1r =  c1*(data[i1] + data[i3]);
		h1i =  c1*(data[i2] - data[i4]);
		h2r = -c2*(data[i2] + data[i4]);
		h2i =  c2*(data[i1] - data[i3]);
		data[i1] =  h1r + wr*h2r - wi*h2i;
		data[i2] =  h1i + wr*h2i + wi*h2r;
		data[i3] =  h1r - wr*h2r + wi*h2i;
		data[i4] = -h1i + wr*h2i + wi*h2r;
		wr = (wtemp = wr)*wpr - wi*wpi+wr;
		wi = wi*wpr + wtemp*wpi + wi;
   	}
   	if (isign == 1) 
	{
		data[1] = (h1r = data[1]) + data[2];
		data[2] = h1r - data[2];
   	} 
	else 
	{
		data[1] = c1*((h1r = data[1]) + data[2]);
		data[2] = c1*(h1r - data[2]);
		four1(data, n, -1);
   	}
}

void four1(data, nn, isign)
float data[];
int nn, isign;
{
	int n, mmax, m, j, istep, i;
  	double wtemp, wr, wpr, wpi, wi, theta;
 	float tempr, tempi;
    
  	n = nn << 1;
  	j = 1;
  	for (i = 1; i < n; i += 2) 	
	{
		if (j > i) 
		{
	    	tempr = data[j];     
			data[j] = data[i];     
			data[i] = tempr;
	    	tempr = data[j+1]; 
			data[j+1] = data[i+1]; 
			data[i+1] = tempr;
		}
		m = n >> 1;
		while (m >= 2 && j > m) 
		{
	   		j -= m;
	    	m >>= 1;
		}	
		j += m;
  	}
   	mmax = 2;
   	while (n > mmax) /* While loop executed log2nn times */ 
	{
		istep = 2*mmax;
		theta = TWOPI/(isign*mmax); /* Trigonometric Recurrence */
		wtemp = sin(0.5*theta);
		wpr = -2.0*wtemp*wtemp;
		wpi = sin(theta);
		wr = 1.0;
		wi = 0.0;
		for (m = 1; m < mmax; m += 2) 
		{
	    	for (i = m; i <= n; i += istep) 
			{
				/* The Danielson-Lanczos formula */
				j = i + mmax;
				tempr = wr*data[j] - wi*data[j+1];
				tempi = wr*data[j+1] + wi*data[j];
				data[j] = data[i] - tempr;
				data[j+1] = data[i+1] - tempi;
				data[i] += tempr;
				data[i+1] += tempi;
	    	}
	    	wr = (wtemp = wr)*wpr - wi*wpi + wr; /* Trigonometric Recurrence */
	    	wi = wi*wpr + wtemp*wpi + wi;
		}
		mmax = istep;
	}
}


#include <stdio.h>
#include <stdlib.h>

int main(int argc, char * argv[])
{
  	FILE * wavefile; 			/* Input wave file - .wav */
  	FILE * outd; 				/* Analyzed result in floats - realwave.dat */
  	int i, fsize, sread, swrite, nbytes, rate, avgrate, csize, ibyte, smin, smax, savg, bad, nbread;						
  	short ccode, channels, blockalign, bps;
  	char riff[4], data[4], sbyte, more[4], fmt[4], wave[4];
  
  	printf("readwave.c executing \n");
 	if(argc<2)	
	{
		printf("Please specify .wav filename!\n");
    	exit(1);
	}
  	
	wavefile = fopen(argv[1], "rb");
  	if(wavefile == NULL)
  	{
    	printf("Can not open %s for reading. \n", argv[1]);
    	exit(1);
  	}
 	printf("No data output file given, opening realwave.dat \n");
  	
	outd = fopen("realwave.dat","w");
  	if(outd == NULL)
  	{
    	printf("Can not open wavefile.dat for writing. \n");
      	exit(1);
   	}
	
	/* The first 44 bytes of a wav file can tell you alot! */
  	printf("Reading WAV Header information...\n");  

  	sread = fread(&riff[0], 1, 4, wavefile);
  	printf("First 4 bytes of .wav file should say RIFF, File says: %c%c%c%c \n",
         riff[0],riff[1],riff[2],riff[3]);

  	sread = fread(&fsize, 1, 4, wavefile);
  	printf("File has %d +8 bytes \n", fsize);

  	sread = fread(&wave[0], 1, 4, wavefile);
  	printf("File should should say WAVE, Files says: %c%c%c%c \n",wave[0],wave[1],wave[2],wave[3]);

  	sread = fread(&fmt[0], 1, 4, wavefile);
  	printf("File should say fmt, File says: %c%c%c%c \n",fmt[0],fmt[1],fmt[2],fmt[3]);

  	sread = fread(&nbytes, 1, 4, wavefile);
  	printf("Block has %d bytes \n", nbytes);

  	sread = fread(&ccode, 1, 2, wavefile);
  	printf("Compression Code = %d \n", ccode);

  	sread = fread(&channels, 1, 2, wavefile);
  	printf("Number of Channels = %d \n", channels);

  	sread = fread(&rate, 1, 4, wavefile);
  	printf("Rate = %d  \n", rate);

  	sread = fread(&avgrate, 1, 4, wavefile);
  	printf("Average Rate = %d \n", avgrate);

  	sread = fread(&blockalign, 1, 2, wavefile);
  	printf("Block Align = %d  \n", blockalign);

  	sread = fread(&bps, 1, 2, wavefile);
  	printf("Bits per Sample = %d \n", bps);

  	sread = fread(&data[0], 1, 4, wavefile);
  	printf("File should say DATA, File says: %c%c%c%c \n",data[0],data[1],data[2],data[3]);
	
  	sread = fread(&csize, 1, 4, wavefile);
  	nbread = 44;
  	bad = 0;
  	savg = 0;

	printf("Begin analyzing sound file!\n");
  	for(i=0; i<csize; i++)
  	{
    	sread = fread(&sbyte, 1, 1, wavefile);
    	if	(sread != 1 && bad==0) 
		{ 
			bad=1; 
			printf("no read on byte %d \n", i); 
		} 
   		fprintf(outd,"%9.5f\n", (double)sbyte/128.0);
    	ibyte = sbyte;
    	savg = savg + ibyte;
    	if (i==0) 
		{
			smin=ibyte; 
			smax=ibyte;
		}
    	smin = ibyte<smin?ibyte:smin;
    	smax = ibyte>smax?ibyte:smax;
	}
  	savg = savg / csize;
  	printf("smin=%d, smax=%d, savg=%d \n", smin, smax, savg);

  	nbread = nbread+csize;
 	while(1)
	{
		sread = fread(&more[0], 1, 4, wavefile);
    	if(sread != 4) goto done;	/* No more bytes to read */
    	
    	sread = fread(&csize, 1, 4, wavefile); /* check for more chunks */
    	if(sread != 4)
		{
			goto done;
		}
		
    	for(i=0; i<csize; i++)
    	{
      		sread = fread(&sbyte, 1, 1, wavefile);
      		if(sread != 1) 
			{
				goto done;		
			}
      		fprintf(outd,"%9.5f\n", (double)sbyte/128.0); /* Save sample as float to file buffer */
    	}
    	nbread = nbread + 8 + csize;
	} 

done: ;

	fflush(outd);
	fclose(outd);
	fclose(wavefile);

	if(argc<4) 
	{
		printf("Reading .wav file complete. New realwave.dat file written.\n");
		printf("You can now use the ./fft_wave program.\n");
	}  
 	return 0;

}
